import math

import torch
from torch import nn
from torch.nn import functional as F


class ResidualConvBlock(nn.Module):
    def __init__(self, ch, res_scale=1.0):
        super().__init__()
        self.conv1 = nn.Conv2d(ch, ch, 3, padding=1)
        self.conv2 = nn.Conv2d(ch, ch, 3, padding=1)
        self.act = nn.SiLU(inplace=True)
        self.res_scale = float(res_scale)

    def forward(self, x):
        r = self.conv2(self.act(self.conv1(x)))
        return x + self.res_scale * r


class BoundedResidualScale(nn.Module):
    def __init__(self, init=0.20, max_value=1.0):
        super().__init__()
        self.max_value = float(max_value)
        init = float(max(1e-5, min(init, self.max_value - 1e-5)))
        p = init / self.max_value
        logit = math.log(p / max(1.0 - p, 1e-8))
        self.logit = nn.Parameter(torch.tensor(logit, dtype=torch.float32))

    def value(self):
        return self.max_value * torch.sigmoid(self.logit)

    def forward(self, x):
        return x * self.value().to(dtype=x.dtype, device=x.device)


class LayerNorm2d(nn.Module):
    """Channel LayerNorm for NCHW tensors."""

    def __init__(self, channels: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(1, channels, 1, 1))
        self.bias = nn.Parameter(torch.zeros(1, channels, 1, 1))
        self.eps = float(eps)

    def forward(self, x):
        mean = x.mean(dim=1, keepdim=True)
        var = (x - mean).square().mean(dim=1, keepdim=True)
        return (x - mean) * torch.rsqrt(var + self.eps) * self.weight + self.bias


class ShallowEncoder(nn.Module):
    def __init__(self, in_channels: int, channels: int, num_blocks: int):
        super().__init__()
        self.head = nn.Conv2d(in_channels, channels, 3, padding=1)
        self.body = nn.Sequential(
            *[ResidualConvBlock(channels, res_scale=0.2) for _ in range(int(num_blocks))]
        )

    def forward(self, x):
        return self.body(F.silu(self.head(x), inplace=True))


class MultiSliceReferenceEncoder(nn.Module):
    def __init__(self, channels: int, num_blocks: int = 1):
        super().__init__()
        self.shared = ShallowEncoder(1, channels, num_blocks)
        hidden = max(8, channels // 4)
        self.score = nn.Sequential(
            nn.Conv2d(channels * 3, hidden, 1),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, 1, 1),
        )
        self.refine = ResidualConvBlock(channels, res_scale=0.2)

    def forward(self, prev, curr, nxt):
        # Encode all three reference slices in one batch.
        batch = prev.shape[0]
        feat_all = self.shared(torch.cat([prev, curr, nxt], dim=0))
        feats = torch.stack(feat_all.split(batch, dim=0), dim=1)  # B,3,C,H,W
        center = feats[:, 1:2].expand_as(feats)

        score_input = torch.cat([feats, center, torch.abs(feats - center)], dim=2)
        b, slices, channels3, h, w = score_input.shape
        logits = self.score(score_input.reshape(b * slices, channels3, h, w))
        logits = logits.view(b, slices, 1, h, w)
        center_bias = logits.new_tensor([0.0, 0.5, 0.0]).view(1, 3, 1, 1, 1)
        weight = torch.softmax(logits + center_bias, dim=1)
        fused = (weight * feats).sum(dim=1)
        return self.refine(fused)
