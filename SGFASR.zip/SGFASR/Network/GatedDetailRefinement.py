from torch import nn
from torch.nn import functional as F

from .layers import BoundedResidualScale, LayerNorm2d


class GatedDetailFFN(nn.Module):
    def __init__(self, channels: int, expand: float = 2.0):
        super().__init__()
        hidden = max(channels, int(round(channels * expand)))
        self.norm = LayerNorm2d(channels)
        self.in_proj = nn.Conv2d(channels, hidden * 2, 1)
        self.dw3 = nn.Conv2d(hidden * 2, hidden * 2, 3, padding=1, groups=hidden * 2)
        self.dw5 = nn.Conv2d(hidden, hidden, 5, padding=2, groups=hidden)
        self.channel = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(hidden, hidden, 1),
            nn.Sigmoid(),
        )
        self.out_proj = nn.Conv2d(hidden, channels, 1)
        self.scale = BoundedResidualScale(0.10, max_value=0.50)

    def forward(self, x):
        z = self.dw3(self.in_proj(self.norm(x)))
        a, b = z.chunk(2, dim=1)
        z = F.gelu(a) * b
        z = z + self.dw5(z)
        z = z * self.channel(z)
        return x + self.scale(self.out_proj(z))


class ConvolutionalRefinement(nn.Module):
    def __init__(self, channels, target_params):
        super().__init__()
        # Choose the hidden width to match the target parameter count.
        hidden = max(1, int(round((target_params - 3 * channels - 1) / (2 * channels + 11))))
        self.norm = LayerNorm2d(channels)
        self.in_proj = nn.Conv2d(channels, hidden, 1)
        self.dw3 = nn.Conv2d(hidden, hidden, 3, padding=1, groups=hidden)
        self.out_proj = nn.Conv2d(hidden, channels, 1)
        self.scale = BoundedResidualScale(0.10, max_value=0.50)

    def forward(self, x):
        z = F.gelu(self.in_proj(self.norm(x)))
        z = F.gelu(self.dw3(z))
        return x + self.scale(self.out_proj(z))


class GatedDetailRefinement(nn.Module):
    def __init__(self, channels, expand):
        super().__init__()
        self.ffn = GatedDetailFFN(channels, expand)
        self.local = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
            nn.SiLU(),
            nn.Conv2d(channels, channels, 1),
        )
        self.scale = BoundedResidualScale(0.08, 0.40)

    def forward(self, x):
        x = self.ffn(x)
        return x + self.scale(self.local(x))
