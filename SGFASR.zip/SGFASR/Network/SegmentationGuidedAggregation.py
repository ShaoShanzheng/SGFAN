from dataclasses import dataclass
from typing import Optional

import math

import torch
from torch import nn
from torch.nn import functional as F
from .layers import BoundedResidualScale, LayerNorm2d


@dataclass
class SegmentationSpatialGraph:
    horizontal: torch.Tensor  # B, 1, H, W-1
    vertical: torch.Tensor  # B, 1, H-1, W


@torch.no_grad()
def segmentation_guided_spatial_neighborhood_graph(seg):
    """Build the segmentation-weighted four-neighbor graph."""
    if seg is None or seg.ndim != 4 or seg.shape[1] < 2:
        raise ValueError("Spatial correction requires BxKxHxW probabilities, K >= 2")
    prob = seg.float().clamp_min(0)
    prob = prob / prob.sum(1, keepdim=True).clamp_min(1e-8)
    entropy = -(prob * prob.clamp_min(1e-8).log()).sum(1, keepdim=True)
    confidence = (1 - entropy / math.log(prob.shape[1])).clamp(0, 1)
    horizontal = (prob[..., :-1] * prob[..., 1:]).sum(1, keepdim=True)
    horizontal = horizontal * confidence[..., :-1] * confidence[..., 1:]
    vertical = (prob[..., :-1, :] * prob[..., 1:, :]).sum(1, keepdim=True)
    vertical = vertical * confidence[..., :-1, :] * confidence[..., 1:, :]
    return SegmentationSpatialGraph(horizontal, vertical)


class BoundedAssignmentCorrection(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.steps = int(cfg["spatial_steps"])
        self.strength = BoundedResidualScale(
            cfg["spatial_strength_init"], cfg["spatial_strength_max"]
        )

    @staticmethod
    def feature_edges(desc, graph):
        horizontal = ((desc[..., :-1] * desc[..., 1:]).sum(1, keepdim=True) + 1) * 0.5
        vertical = ((desc[..., :-1, :] * desc[..., 1:, :]).sum(1, keepdim=True) + 1) * 0.5
        return graph.horizontal * horizontal.clamp(0, 1), graph.vertical * vertical.clamp(0, 1)

    @staticmethod
    def neighbor_sum(field, horizontal, vertical):
        # Pad the image borders without wraparound.
        result = F.pad(horizontal * field[..., 1:], (0, 1, 0, 0))
        result = result + F.pad(horizontal * field[..., :-1], (1, 0, 0, 0))
        result = result + F.pad(vertical * field[..., 1:, :], (0, 0, 0, 1))
        return result + F.pad(vertical * field[..., :-1, :], (0, 0, 1, 0))

    def forward(self, base_weights, desc, graph):
        if graph is None:
            raise ValueError("Missing segmentation spatial graph")
        b, _, h, w = desc.shape
        anchors = base_weights.transpose(1, 2).reshape(b, -1, h, w)
        horizontal, vertical = self.feature_edges(desc, graph)
        degree = F.pad(horizontal, (0, 1, 0, 0)) + F.pad(horizontal, (1, 0, 0, 0))
        degree = degree + F.pad(vertical, (0, 0, 0, 1)) + F.pad(vertical, (0, 0, 1, 0))
        support = anchors
        for _ in range(self.steps):
            support = (anchors + self.neighbor_sum(support, horizontal, vertical)) / (1 + degree)
        uncertainty = -(anchors * anchors.clamp_min(1e-8).log()).sum(1, keepdim=True)
        uncertainty = (uncertainty / math.log(max(anchors.shape[1], 2))).clamp(0, 1)
        amount = self.strength.value() * uncertainty
        corrected = anchors + amount * (support - anchors)
        return corrected.flatten(2).transpose(1, 2)


@dataclass
class OrganizedFeatures:
    T: Optional[torch.Tensor]
    Pi: Optional[torch.Tensor]
    U: torch.Tensor


class SegmentationGuidedAnchorAggregation(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        c, k = cfg["base_channels"], cfg["seg_num_classes"]
        self.k, self.r = k, cfg["num_anchors"] // k
        self.temperature = cfg["assignment_temperature"]
        self.route_proj = nn.Sequential(
            nn.Conv2d(3 * c, c, 1), nn.SiLU(), nn.Conv2d(c, c, 1)
        )
        self.route_norm = LayerNorm2d(c)
        self.anchors = nn.Parameter(F.normalize(torch.randn(k * self.r, c), dim=-1))
        self.global_proj = nn.Linear(c, c)
        self.mix = nn.Sequential(nn.Linear(3 * c, c), nn.SiLU(), nn.Linear(c, c), nn.Sigmoid())
        self.out = nn.Linear(c, c)

    def configure(self, case, channels, cfg):
        self.use_reference = case["reference"]
        self.use_global_tokens = case["global_branch"]
        self.use_group_order = case["group_branch"]
        if not self.use_reference:
            old = self.route_proj[0]
            new = nn.Conv2d(channels, channels, 1)
            with torch.no_grad():
                new.weight.copy_(old.weight[:, :channels])
                new.bias.copy_(old.bias)
            self.route_proj[0] = new
        if not self.use_global_tokens:
            self.global_proj = None
            self.mix = None
            self.out = None
        elif not self.use_reference:
            self.mix = None
        self.spatial = BoundedAssignmentCorrection(cfg) if case["segmentation"] else None

    def forward(self, F_tar, F_ref, spatial_graph=None):
        batch, _, height, width = F_tar.shape
        pixels = height * width
        inputs = [F_tar, F_ref, (F_tar - F_ref).abs()] if self.use_reference else [F_tar]
        descriptor_map = F.normalize(self.route_norm(self.route_proj(torch.cat(inputs, 1))), dim=1)
        D = descriptor_map.flatten(2).transpose(1, 2)
        A = (D @ F.normalize(self.anchors, dim=-1).t() / self.temperature).softmax(-1)
        A_tilde = A if self.spatial is None else self.spatial(A, descriptor_map, spatial_graph)

        # Sum the weights within each anchor group.
        U = A_tilde.reshape(batch, pixels, self.k, self.r).sum(-1)
        U = U.transpose(1, 2).reshape(batch, self.k, height, width)

        T = None
        if self.use_global_tokens:
            w_sum = A_tilde.sum(1).unsqueeze(-1).clamp_min(1e-6)
            assignments = A_tilde.transpose(1, 2)
            pooled_tar = assignments @ F_tar.flatten(2).transpose(1, 2) / w_sum
            pooled = pooled_tar
            if self.use_reference:
                pooled_ref = assignments @ F_ref.flatten(2).transpose(1, 2) / w_sum
                gate_input = torch.cat([pooled_tar, pooled_ref, (pooled_tar - pooled_ref).abs()], -1)
                pooled = pooled_tar + self.mix(gate_input) * (pooled_ref - pooled_tar)
            T = self.out(pooled + 0.10 * self.global_proj(self.anchors).unsqueeze(0))

        Pi = None
        if self.use_group_order:
            max_weight, dominant_anchor = A_tilde.max(-1)
            Pi = (dominant_anchor.float() + 0.49 * (1 - max_weight)).argsort(1)
        return OrganizedFeatures(T, Pi, U)
