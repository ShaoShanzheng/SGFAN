from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F


class ConvNormAct(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, k: int = 3, s: int = 1, p: int = 1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=k, stride=s, padding=p, bias=False),
            nn.InstanceNorm2d(out_ch, affine=True),
            nn.LeakyReLU(0.1, inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class ResidualBlock(nn.Module):
    def __init__(self, ch: int, dropout: float = 0.0):
        super().__init__()
        self.conv1 = ConvNormAct(ch, ch)
        self.conv2 = nn.Sequential(
            nn.Conv2d(ch, ch, kernel_size=3, padding=1, bias=False),
            nn.InstanceNorm2d(ch, affine=True),
        )
        self.act = nn.LeakyReLU(0.1, inplace=True)
        self.drop = nn.Dropout2d(dropout) if dropout > 0 else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv1(x)
        out = self.drop(out)
        out = self.conv2(out)
        return self.act(out + x)


class DownBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, dropout: float):
        super().__init__()
        self.down = ConvNormAct(in_ch, out_ch, k=3, s=2, p=1)
        self.res = ResidualBlock(out_ch, dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.down(x)
        x = self.res(x)
        return x


class UpBlock(nn.Module):
    def __init__(self, in_ch: int, skip_ch: int, out_ch: int, dropout: float):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2)
        self.fuse = ConvNormAct(out_ch + skip_ch, out_ch)
        self.res = ResidualBlock(out_ch, dropout)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = self.up(x)
        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        x = torch.cat([x, skip], dim=1)
        x = self.fuse(x)
        x = self.res(x)
        return x


class ResUNet(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, base_channels: int = 32, dropout: float = 0.1):
        super().__init__()
        c1 = base_channels
        c2 = c1 * 2
        c3 = c2 * 2
        c4 = c3 * 2
        c5 = c4 * 2

        self.stem = nn.Sequential(
            ConvNormAct(in_channels, c1),
            ResidualBlock(c1, dropout),
        )
        self.enc2 = DownBlock(c1, c2, dropout)
        self.enc3 = DownBlock(c2, c3, dropout)
        self.enc4 = DownBlock(c3, c4, dropout)
        self.bottleneck = DownBlock(c4, c5, dropout)

        self.dec4 = UpBlock(c5, c4, c4, dropout)
        self.dec3 = UpBlock(c4, c3, c3, dropout)
        self.dec2 = UpBlock(c3, c2, c2, dropout)
        self.dec1 = UpBlock(c2, c1, c1, dropout)

        self.head = nn.Conv2d(c1, out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor, return_features: bool = False):
        e1 = self.stem(x)
        e2 = self.enc2(e1)
        e3 = self.enc3(e2)
        e4 = self.enc4(e3)
        b = self.bottleneck(e4)

        d4 = self.dec4(b, e4)
        d3 = self.dec3(d4, e3)
        d2 = self.dec2(d3, e2)
        d1 = self.dec1(d2, e1)
        logits = self.head(d1)

        if return_features:
            feats = {
                "enc1": e1,
                "enc2": e2,
                "enc3": e3,
                "enc4": e4,
                "bottleneck": b,
            }
            return logits, feats
        return logits


def load_frozen_seg_model(cfg, device):
    model = ResUNet(
        in_channels=3,
        out_channels=cfg["seg_num_classes"],
        base_channels=cfg["seg_base_channels"],
        dropout=cfg["seg_dropout"],
    ).to(device)
    ckpt_path = Path(cfg["seg_ckpt"])
    if not ckpt_path.exists():
        raise FileNotFoundError(f"seg_ckpt not found: {ckpt_path}")
    ckpt = torch.load(str(ckpt_path), map_location=device, weights_only=False)
    state = ckpt["model"] if isinstance(ckpt, dict) and "model" in ckpt else ckpt
    model.load_state_dict(state, strict=True)
    model.eval()
    for p in model.parameters():
        p.requires_grad = False
    return model


@torch.no_grad()
def infer_segmentation_prior(
    seg_model, pd_prev_up, pd_curr_up, pd_next_up, num_classes: int, temperature: float = 1.0
):
    pd_3ch = torch.cat([pd_prev_up, pd_curr_up, pd_next_up], dim=1)
    logits = seg_model(pd_3ch)
    if logits.shape[1] != num_classes:
        raise RuntimeError(
            f"Segmentation output channels mismatch: got {logits.shape[1]}, expected {num_classes}"
        )
    prob = torch.softmax(logits.float() / max(float(temperature), 1e-6), dim=1)
    return prob
