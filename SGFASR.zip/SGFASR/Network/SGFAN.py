import torch
from torch import nn
from torch.nn import functional as F

from .SegmentationGuidedAggregation import (
    SegmentationGuidedAnchorAggregation,
    segmentation_guided_spatial_neighborhood_graph,
)
from .TriBranchFusion import TriBranchFusion
from .GatedDetailRefinement import ConvolutionalRefinement, GatedDetailRefinement
from .layers import MultiSliceReferenceEncoder, ShallowEncoder


MODEL_CONFIG = {
    "ablation": "full",
    "seed": 42,
    "base_channels": 48,
    "seg_num_classes": 8,
    "num_blocks": 6,
    "num_heads": 4,
    "num_anchors": 24,
    "assignment_temperature": 0.2,
    "spatial_steps": 2,
    "spatial_strength_init": 0.05,
    "spatial_strength_max": 0.25,
    "subgroup_size": 32,
    "token_attention_logit_scale": 1.0,
    "ffn_expand": 2.0,
    "t2_stem_resblocks": 2,
    "pd_stem_resblocks": 1,
}

FULL_MODEL = {
    "segmentation": True,
    "reference": True,
    "group_branch": True,
    "global_branch": True,
    "edge": True,
    "plain": False,
}

ABLATIONS = {
    "full": FULL_MODEL,
    "w/o Seg. Correction": dict(FULL_MODEL, segmentation=False),
    "w/o EDIB": dict(FULL_MODEL, edge=False),
    "w/ ConvRefine": dict(FULL_MODEL, plain=True),
    "w/o Ref": dict(FULL_MODEL, reference=False, segmentation=False),
    "w/o ATAB": dict(FULL_MODEL, global_branch=False),
    "w/o GCAB": dict(FULL_MODEL, group_branch=False),
}


class ReconstructionBlock(TriBranchFusion):
    def __init__(self, cfg):
        super().__init__(cfg)
        self.refinement = GatedDetailRefinement(cfg["base_channels"], cfg["ffn_expand"])

    def forward(self, F_tar, F_ref, features):
        fused = super().forward(F_tar, F_ref, features)
        return self.refinement(fused)


class SGFAN(nn.Module):
    def __init__(self, cfg=None):
        super().__init__()
        cfg = dict(MODEL_CONFIG if cfg is None else cfg)
        self.case = ABLATIONS[cfg["ablation"]]
        self.num_classes = cfg["seg_num_classes"]
        c = cfg["base_channels"]
        self.target_encoder = ShallowEncoder(1, c, cfg["t2_stem_resblocks"])
        self.reference_encoder = MultiSliceReferenceEncoder(c, cfg["pd_stem_resblocks"])
        self.aggregator = SegmentationGuidedAnchorAggregation(cfg)
        self.blocks = nn.ModuleList([ReconstructionBlock(cfg) for _ in range(cfg["num_blocks"])])
        self.trunk = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1), nn.SiLU(), nn.Conv2d(c, c, 3, padding=1)
        )
        self.recon_head = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1), nn.SiLU(), nn.Conv2d(c, 1, 3, padding=1)
        )
        nn.init.normal_(self.recon_head[-1].weight, std=1e-3)
        nn.init.zeros_(self.recon_head[-1].bias)
        # Isolate ablation initialization from the training RNG.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(cfg["seed"] + 7919)
            self.aggregator.configure(self.case, c, cfg)
            if not self.case["reference"]:
                self.reference_encoder = None
            for block in self.blocks:
                if not self.case["group_branch"]:
                    block.group = None
                    block.fusion.active_branch_mask[0] = False
                if not self.case["global_branch"]:
                    block.center = None
                    block.fusion.active_branch_mask[1] = False
                if not self.case["edge"]:
                    block.edge = None
                    block.fusion.active_branch_mask[2] = False
                elif not self.case["reference"]:
                    block.edge.confidence = None
                if self.case["plain"]:
                    target = sum(p.numel() for p in block.refinement.parameters())
                    block.refinement = ConvolutionalRefinement(c, target)

    def forward(self, lr_up, pd_prev_up=None, pd_curr_up=None, pd_next_up=None, seg_prob=None):
        """Reconstruct from bicubic-upsampled LR input."""
        if lr_up.ndim != 4 or lr_up.shape[1] != 1:
            raise ValueError("lr_up must have shape Bx1xHxW")
        size = lr_up.shape[-2:]
        I_up = lr_up
        shallow = self.target_encoder(I_up)
        if self.case["reference"]:
            refs = (pd_prev_up, pd_curr_up, pd_next_up)
            if any(ref is None for ref in refs):
                raise ValueError("This experiment requires three registered reference slices")
            if any(ref.shape != lr_up.shape for ref in refs):
                raise ValueError("Reference slices must match the target output grid and batch")
            F_ref = self.reference_encoder(*refs)
        else:
            F_ref = None
        if self.case["segmentation"]:
            if seg_prob is None or seg_prob.shape[:2] != (lr_up.shape[0], self.num_classes):
                raise ValueError("This experiment requires BxKxHxW segmentation probabilities")
            if seg_prob.shape[-2:] != size:
                raise ValueError("Segmentation probabilities must match the output grid")
            P = seg_prob.float().clamp_min(1e-8)
            P = P / P.sum(1, keepdim=True)
            spatial_graph = segmentation_guided_spatial_neighborhood_graph(P)
        else:
            spatial_graph = None

        F_tar = shallow
        for block in self.blocks:
            reference = F_ref if self.case["reference"] else F_tar
            features = self.aggregator(F_tar, reference, spatial_graph)
            F_tar = block(F_tar, reference, features)

        residual = self.recon_head(shallow + self.trunk(F_tar))
        return (I_up + residual).clamp(0, 1)

    def reconstruct(self, lr, scale, pd_prev=None, pd_curr=None, pd_next=None, seg_prob=None):
        if scale not in (2, 4):
            raise ValueError("Supported reconstruction scales are 2 and 4")
        up = F.interpolate(lr, scale_factor=scale, mode="bicubic", align_corners=False).clamp(0, 1)
        return self(up, pd_prev, pd_curr, pd_next, seg_prob)
