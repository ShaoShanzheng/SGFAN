import math
from typing import Tuple

import torch
from torch import nn
from torch.nn import functional as F
from .layers import BoundedResidualScale, LayerNorm2d


def feature_group_boundary(U: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Compute the EDIB edge-support and entropy maps B and E from U."""
    U = U.float().clamp_min(1e-8)
    U = U / U.sum(dim=1, keepdim=True).clamp_min(1e-6)
    group_count = U.shape[1]
    E = -(U * U.log()).sum(dim=1, keepdim=True) / math.log(max(group_count, 2))
    dx = F.pad((U[..., 1:] - U[..., :-1]).abs(), (0, 1, 0, 0))
    dy = F.pad((U[:, :, 1:, :] - U[:, :, :-1, :]).abs(), (0, 0, 0, 1))
    delta = torch.maximum(dx.amax(dim=1, keepdim=True), dy.amax(dim=1, keepdim=True))
    B = torch.maximum(1.0 - torch.exp(-4.0 * delta), 0.35 * E)
    B = F.max_pool2d(B, 3, stride=1, padding=1).clamp(0.0, 1.0)
    return B, E


class GroupedCrossAttentionBranch(nn.Module):
    def __init__(self, channels: int, num_heads: int, subgroup_size: int):
        super().__init__()
        if channels % num_heads != 0:
            raise ValueError("channels must be divisible by num_heads")
        self.num_heads = int(num_heads)
        self.head_dim = channels // num_heads
        self.group_size = int(subgroup_size)
        self.q_norm = nn.LayerNorm(channels)
        self.kv_norm = nn.LayerNorm(channels)
        self.q = nn.Linear(channels, channels)
        self.k = nn.Linear(channels, channels)
        self.v = nn.Linear(channels, channels)
        self.proj = nn.Linear(channels, channels)
        self.q_cpe = nn.Conv2d(channels, channels, 3, padding=1, groups=channels)
        self.kv_cpe = nn.Conv2d(channels, channels, 3, padding=1, groups=channels)

    @staticmethod
    def _gather_tokens(tokens, order):
        return torch.gather(tokens, 1, order.unsqueeze(-1).expand(-1, -1, tokens.shape[-1]))

    def forward(self, F_tar, F_ref, Pi):
        b, c, h, w = F_tar.shape
        n = h * w
        target = (F_tar + self.q_cpe(F_tar)).flatten(2).transpose(1, 2).contiguous()
        reference = (F_ref + self.kv_cpe(F_ref)).flatten(2).transpose(1, 2).contiguous()
        xs = self._gather_tokens(target, Pi)
        ps = self._gather_tokens(reference, Pi)

        pad = (self.group_size - n % self.group_size) % self.group_size
        if pad:
            valid = torch.ones(b, n, device=F_tar.device, dtype=torch.bool)
            xs = torch.cat([xs, xs[:, -1:].expand(-1, pad, -1)], dim=1)
            ps = torch.cat([ps, ps[:, -1:].expand(-1, pad, -1)], dim=1)
            valid = torch.cat(
                [valid, torch.zeros(b, pad, device=F_tar.device, dtype=torch.bool)], dim=1
            )
        groups = xs.shape[1] // self.group_size
        xs = xs.view(b, groups, self.group_size, c)
        ps = ps.view(b, groups, self.group_size, c)
        next_ps = torch.cat([ps[:, 1:], ps[:, -1:]], dim=1)
        kv = torch.cat([ps, next_ps], dim=2)

        bg = b * groups
        Q_g = (
            self.q(self.q_norm(xs))
            .view(bg, self.group_size, self.num_heads, self.head_dim)
            .transpose(1, 2)
        )
        kv_normed = self.kv_norm(kv)
        K_g = (
            self.k(kv_normed)
            .view(bg, self.group_size * 2, self.num_heads, self.head_dim)
            .transpose(1, 2)
        )
        V_g = (
            self.v(kv_normed)
            .view(bg, self.group_size * 2, self.num_heads, self.head_dim)
            .transpose(1, 2)
        )
        M_pad = None
        if pad:
            vg = valid.view(b, groups, self.group_size)
            next_v = torch.cat([vg[:, 1:], vg[:, -1:]], dim=1)
            kv_valid = torch.cat([vg, next_v], dim=2)
            M_pad = Q_g.new_zeros(bg, 1, 1, self.group_size * 2)
            M_pad = M_pad.masked_fill(~kv_valid.view(bg, 1, 1, self.group_size * 2), -1e4)
        out = F.scaled_dot_product_attention(
            Q_g, K_g, V_g, attn_mask=M_pad, dropout_p=0.0, is_causal=False
        )
        out = out.transpose(1, 2).contiguous().view(b, groups * self.group_size, c)[:, :n]
        out = self.proj(out)

        restored = torch.zeros_like(out)
        restored.scatter_(1, Pi.unsqueeze(-1).expand(-1, -1, c), out)
        return restored.transpose(1, 2).view(b, c, h, w).contiguous()


class AggregatedTokenAttentionBranch(nn.Module):
    def __init__(self, channels, num_heads, similarity_bias_strength):
        super().__init__()
        if channels % num_heads:
            raise ValueError("channels must be divisible by num_heads")
        self.num_heads = int(num_heads)
        self.head_dim = channels // num_heads
        self.scale = self.head_dim**-0.5
        self.similarity_bias_strength = float(similarity_bias_strength)
        self.q_norm = LayerNorm2d(channels)
        self.c_norm = nn.LayerNorm(channels)
        self.q = nn.Conv2d(channels, channels, 1)
        self.k = nn.Linear(channels, channels)
        self.v = nn.Linear(channels, channels)
        self.proj = nn.Conv2d(channels, channels, 1)

    def forward(self, F_tar, T):
        b, c, h, w = F_tar.shape
        n, m = h * w, T.shape[1]
        Q_a = self.q(self.q_norm(F_tar)).flatten(2).transpose(1, 2)
        Q_a = Q_a.view(b, n, self.num_heads, self.head_dim).transpose(1, 2)
        T = self.c_norm(T)
        K_a = self.k(T).view(b, m, self.num_heads, self.head_dim).transpose(1, 2)
        V_a = self.v(T).view(b, m, self.num_heads, self.head_dim).transpose(1, 2)
        similarity = torch.matmul(Q_a, K_a.transpose(-2, -1)) * self.scale
        attn = torch.softmax(self.similarity_bias_strength * similarity, dim=-1)
        out = torch.matmul(attn, V_a).transpose(1, 2).contiguous().view(b, n, c)
        return self.proj(out.transpose(1, 2).view(b, c, h, w))


class EdgeDetailInteractionBranch(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        hidden = max(16, channels // 2)
        self.confidence = nn.Sequential(
            nn.Conv2d(channels * 3 + 2, hidden, 1),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, channels, 1),
            nn.Sigmoid(),
        )
        self.dw3 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels)
        self.dw5 = nn.Conv2d(channels, channels, 5, padding=4, dilation=2, groups=channels)
        self.out = nn.Sequential(
            nn.Conv2d(channels * 2, channels, 1),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1),
        )

    @staticmethod
    def _highpass(x):
        low = F.avg_pool2d(x, 3, stride=1, padding=1)
        return x - low

    def forward(self, F_tar, F_ref, B, E):
        target_detail, ref_detail = self._highpass(F_tar), self._highpass(F_ref)
        conf = (
            self.confidence(torch.cat(
                [target_detail, ref_detail, (target_detail - ref_detail).abs(), B, E], dim=1
            ))
            if self.confidence is not None
            else 0.0
        )
        transfer = target_detail + conf * (ref_detail - target_detail)
        F_edge = self.out(torch.cat([self.dw3(transfer), self.dw5(transfer)], dim=1))
        return (0.10 + 0.90 * B) * F_edge


class DynamicFeatureFusion(nn.Module):
    def __init__(self, channels: int, num_classes: int):
        super().__init__()
        self.register_buffer(
            "active_branch_mask", torch.ones(3, dtype=torch.bool), persistent=False
        )
        hidden = max(16, channels // 2)
        self.gate = nn.Sequential(
            nn.Linear(channels + num_classes + 1, hidden),
            nn.SiLU(inplace=True),
            nn.Linear(hidden, channels * 3),
        )
        # Initialize each sigmoid gate to 1/3.
        nn.init.zeros_(self.gate[-1].weight)
        nn.init.constant_(self.gate[-1].bias, -math.log(2.0))
        self.fuse = nn.Sequential(
            nn.Conv2d(channels * 3, channels, 1),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1),
        )
        self.scale = BoundedResidualScale(0.15, max_value=0.60)

    def compute_gates(self, F_tar, U, B):
        pooled = F_tar.mean(dim=(2, 3))
        group_prevalence = U.mean(dim=(2, 3))
        edge_support = B.mean(dim=(2, 3))
        gate = self.gate(torch.cat([pooled, group_prevalence, edge_support], dim=1))
        gate = gate.view(F_tar.shape[0], 3, F_tar.shape[1], 1, 1)
        active = self.active_branch_mask.view(1, 3, 1, 1, 1).to(gate.dtype)
        gate = torch.sigmoid(gate) * active
        return gate

    def forward(self, F_tar, O_g, O_a, O_e, U, B):
        gate = self.compute_gates(F_tar, U, B)
        fused = torch.cat([gate[:, 0] * O_g, gate[:, 1] * O_a, gate[:, 2] * O_e], dim=1)
        return F_tar + self.scale(self.fuse(fused))


class TriBranchFusion(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        c, k = cfg["base_channels"], cfg["seg_num_classes"]
        self.group = GroupedCrossAttentionBranch(c, cfg["num_heads"], cfg["subgroup_size"])
        self.center = AggregatedTokenAttentionBranch(
            c, cfg["num_heads"], cfg["token_attention_logit_scale"]
        )
        self.edge = EdgeDetailInteractionBranch(c)
        self.fusion = DynamicFeatureFusion(c, k)

    def forward(self, F_tar, F_ref, features):
        B, E = feature_group_boundary(features.U)
        O_g = (
            self.group(F_tar, F_ref, features.Pi)
            if self.group is not None
            else torch.zeros_like(F_tar)
        )
        O_a = (
            self.center(F_tar, features.T)
            if self.center is not None
            else torch.zeros_like(F_tar)
        )
        O_e = (
            self.edge(F_tar, F_ref, B, E)
            if self.edge is not None
            else torch.zeros_like(F_tar)
        )
        return self.fusion(F_tar, O_g, O_a, O_e, features.U, B)
