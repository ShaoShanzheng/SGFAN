"""Train SGFAN."""

import argparse
import math
import random
from copy import deepcopy
from importlib import import_module
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from Network import SGFAN
from Network.ResUNet import infer_segmentation_prior, load_frozen_seg_model
from Network.SGFAN import ABLATIONS, MODEL_CONFIG
from utils import (
    capture_rng, psnr_torch, restore_rng, save_checkpoint_atomic,
    seed_everything, set_epoch_learning_rate, ssim_torch,
)


TRAIN_CONFIG = dict(
    MODEL_CONFIG,
    epochs=1000,
    batch_size=8,
    val_batch_size=8,
    micro_batch_size=8,
    val_micro_batch_size=8,
    train_patch_size=128,
    lr=2e-4,
    min_lr=1e-6,
    warmup_epochs=5,
    lr_decay_epochs=400,
    adam_betas=(0.9, 0.99),
    weight_decay=0.0,
    grad_clip=1.0,
    model_ema_decay=0.999,
    early_stop_patience=30,
    lambda_l1=1.0,
    seg_base_channels=32,
    seg_dropout=0.1,
    seg_temperature=1.0,
    deterministic=False,
    device="cuda:0",
)


def forward_batch(model, segmenter, I_up, pd_slices, cfg):
    P = None
    if segmenter is not None:
        P = infer_segmentation_prior(
            segmenter, *pd_slices, cfg["seg_num_classes"], cfg["seg_temperature"]
        )
    return model(I_up, *pd_slices, seg_prob=P)


def prepare_batch(batch, scale, device, use_reference):
    I_lr = batch["lr"].to(device, non_blocking=True)
    I_hr = batch["hr"].to(device, non_blocking=True)
    I_up = F.interpolate(
        I_lr, scale_factor=scale, mode="bicubic", align_corners=False
    ).clamp(0, 1)
    if I_up.shape != I_hr.shape:
        raise ValueError(f"LR and HR do not match at x{scale}.")
    pd_slices = [
        batch[key].to(device, non_blocking=True)
        for key in ("pd_prev", "pd_curr", "pd_next")
    ] if use_reference else []
    return I_up, I_hr, pd_slices


def round_robin_batches(loaders, epoch):
    scales = list(loaders)
    random.Random(1009 + epoch).shuffle(scales)
    pending = {scale: iter(loaders[scale]["train"]) for scale in scales}
    while pending:
        for scale in list(pending):
            batch = next(pending[scale], None)
            if batch is None:
                del pending[scale]
            else:
                yield scale, batch


@torch.no_grad()
def update_ema(averaged_model, model, decay):
    for average, current in zip(averaged_model.parameters(), model.parameters()):
        average.lerp_(current, 1 - decay)
    for average, current in zip(averaged_model.buffers(), model.buffers()):
        average.copy_(current)


def train_epoch(model, averaged_model, segmenter, loaders, optimizer, cfg, epoch):
    model.train()
    total_loss, samples = 0.0, 0
    for scale, batch in round_robin_batches(loaders, epoch):
        I_up, I_hr, pd_slices = prepare_batch(batch, scale, cfg["device"], model.case["reference"])
        batch_size = I_hr.size(0)
        optimizer.zero_grad(set_to_none=True)
        for start in range(0, batch_size, cfg["micro_batch_size"]):
            stop = min(start + cfg["micro_batch_size"], batch_size)
            section = slice(start, stop)
            prediction = forward_batch(model, segmenter, I_up[section], [p[section] for p in pd_slices], cfg)
            loss = cfg["lambda_l1"] * F.l1_loss(prediction, I_hr[section])
            if not torch.isfinite(loss):
                raise FloatingPointError("Non-finite SR loss.")
            count = stop - start
            (loss * (count / batch_size)).backward()
            total_loss += loss.detach().item() * count
            samples += count
        if cfg["grad_clip"] > 0:
            nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"], error_if_nonfinite=True)
        optimizer.step()
        update_ema(averaged_model, model, cfg["model_ema_decay"])
    return total_loss / samples


@torch.inference_mode()
def evaluate(model, segmenter, loader, scale, cfg):
    model.eval()
    psnr, ssim = [], []
    for batch in loader:
        I_up, I_hr, pd_slices = prepare_batch(batch, scale, cfg["device"], model.case["reference"])
        for start in range(0, I_hr.size(0), cfg["val_micro_batch_size"]):
            section = slice(start, start + cfg["val_micro_batch_size"])
            target = I_hr[section]
            prediction = forward_batch(model, segmenter, I_up[section], [p[section] for p in pd_slices], cfg)
            if not torch.isfinite(prediction).all():
                raise FloatingPointError("Non-finite SR prediction.")
            psnr.extend(psnr_torch(prediction, target).tolist())
            ssim.extend(ssim_torch(prediction, target).tolist())
    if not psnr:
        raise ValueError("Empty evaluation set.")
    return {"psnr": float(np.mean(psnr)), "ssim": float(np.mean(ssim))}


def main(cfg, build_dataloaders, resume=False):
    """Train with loaders keyed by scale, then by 'train' and 'val'."""
    seed_everything(cfg["seed"])
    torch.use_deterministic_algorithms(cfg["deterministic"])
    torch.backends.cudnn.deterministic = cfg["deterministic"]
    torch.backends.cudnn.benchmark = not cfg["deterministic"]
    out = Path(cfg["out_dir"])
    out.mkdir(parents=True, exist_ok=True)
    latest, best = out / "latest.pth", out / "best.pth"
    if resume and not (latest.is_file() and best.is_file()):
        raise FileNotFoundError("Resume requires latest.pth and best.pth in the output directory.")
    if not resume and (latest.exists() or best.exists()):
        raise FileExistsError("Use a new output directory or pass --resume for this run.")

    loaders = build_dataloaders(cfg)
    model = SGFAN(cfg).to(cfg["device"])
    averaged_model = deepcopy(model).requires_grad_(False).eval()
    segmenter = load_frozen_seg_model(cfg, cfg["device"]) if model.case["segmentation"] else None
    optimizer = torch.optim.Adam(
        model.parameters(), lr=cfg["lr"], betas=cfg["adam_betas"], weight_decay=cfg["weight_decay"]
    )
    start, best_score, best_epoch = 1, -math.inf, 0
    if resume:
        state = torch.load(latest, map_location=cfg["device"], weights_only=False)
        if state["config"] != cfg:
            raise ValueError("Checkpoint configuration differs from the current run.")
        model.load_state_dict(state["model"])
        averaged_model.load_state_dict(state["ema_model"])
        optimizer.load_state_dict(state["optimizer"])
        restore_rng(state["rng"], loaders)
        start, best_score, best_epoch = state["epoch"] + 1, state["best_score"], state["best_epoch"]

    for epoch in range(start, cfg["epochs"] + 1):
        if epoch - 1 - best_epoch >= cfg["early_stop_patience"]:
            break
        lr = set_epoch_learning_rate(optimizer, epoch, cfg)
        loss = train_epoch(model, averaged_model, segmenter, loaders, optimizer, cfg, epoch)
        validation = {
            scale: evaluate(averaged_model, segmenter, entries["val"], scale, cfg)
            for scale, entries in loaders.items()
        }
        score = float(np.mean([metrics["psnr"] for metrics in validation.values()]))
        improved = score > best_score
        if improved:
            best_score, best_epoch = score, epoch
        state = dict(
            epoch=epoch, config=cfg, best_score=best_score, best_epoch=best_epoch,
            model=model.state_dict(), ema_model=averaged_model.state_dict(),
        )
        if improved:
            save_checkpoint_atomic(state, best)
        state.update(optimizer=optimizer.state_dict(), rng=capture_rng(loaders))
        save_checkpoint_atomic(state, latest)
        print(f"Epoch {epoch:04d}  LR {lr:.2e}  L1 {loss:.5f}  validation PSNR {score:.4f}")
    return best_epoch, best_score


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--loader-module", required=True, help="Module providing build_dataloaders(config).")
    parser.add_argument("--scale", type=int, choices=(2, 4), nargs="+", default=[4])
    parser.add_argument("--ablation", choices=tuple(ABLATIONS), default=MODEL_CONFIG["ablation"])
    parser.add_argument("--seg-checkpoint")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--device", default=TRAIN_CONFIG["device"])
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if ABLATIONS[args.ablation]["segmentation"] and not args.seg_checkpoint:
        parser.error("This variant requires the pretrained PD segmentation checkpoint.")
    cfg = dict(TRAIN_CONFIG, scales=sorted(set(args.scale)), ablation=args.ablation,
               seg_ckpt=args.seg_checkpoint, out_dir=args.out_dir, device=args.device,
               loader_module=args.loader_module)
    return cfg, import_module(args.loader_module).build_dataloaders, args.resume


if __name__ == "__main__":
    main(*parse_args())
