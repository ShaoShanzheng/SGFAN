import math
import os
import random
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def save_checkpoint_atomic(obj, path):
    path = Path(path)
    temporary = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    torch.save(obj, temporary)
    os.replace(temporary, path)


def psnr_torch(pred: torch.Tensor, target: torch.Tensor, eps=1e-8) -> torch.Tensor:
    pred = pred.float().clamp(0, 1)
    target = target.float().clamp(0, 1)
    mse = F.mse_loss(pred, target, reduction="none").flatten(1).mean(dim=1)
    return 10.0 * torch.log10(1.0 / (mse + eps))


def _gaussian_kernel_1d(window_size: int, sigma: float, device, dtype):
    coords = torch.arange(window_size, device=device, dtype=dtype) - window_size // 2
    g = torch.exp(-(coords**2) / (2 * sigma**2))
    return g / (g.sum() + 1e-12)


def ssim_torch(
    pred: torch.Tensor, target: torch.Tensor, window_size=11, sigma=1.5, eps=1e-12
) -> torch.Tensor:
    pred = pred.float().clamp(0, 1)
    target = target.float().clamp(0, 1)
    c = pred.shape[1]
    g1 = _gaussian_kernel_1d(window_size, sigma, pred.device, pred.dtype)
    kernel2d = torch.outer(g1, g1).view(1, 1, window_size, window_size).repeat(c, 1, 1, 1)
    pad = window_size // 2

    def filt(x):
        return F.conv2d(F.pad(x, (pad, pad, pad, pad), mode="reflect"), kernel2d, groups=c)

    mu_x, mu_y = filt(pred), filt(target)
    sigma_x2 = filt(pred * pred) - mu_x * mu_x
    sigma_y2 = filt(target * target) - mu_y * mu_y
    sigma_xy = filt(pred * target) - mu_x * mu_y
    c1, c2 = 0.01**2, 0.03**2
    ssim_map = ((2 * mu_x * mu_y + c1) * (2 * sigma_xy + c2)) / (
        (mu_x * mu_x + mu_y * mu_y + c1) * (sigma_x2 + sigma_y2 + c2) + eps
    )
    return ssim_map.flatten(1).mean(dim=1)


def capture_rng(loaders):
    return dict(
        python=random.getstate(),
        numpy=np.random.get_state(),
        torch=torch.get_rng_state(),
        cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
        loaders={
            f"{s}/{split}": loader.generator.get_state()
            for s, entries in loaders.items()
            for split, loader in entries.items()
            if loader.generator is not None
        },
    )


def restore_rng(state, loaders):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if torch.cuda.is_available() and state["cuda"] is not None:
        torch.cuda.set_rng_state_all([x.cpu() for x in state["cuda"]])
    for s, entries in loaders.items():
        for split, loader in entries.items():
            if loader.generator is not None:
                loader.generator.set_state(state["loaders"][f"{s}/{split}"].cpu())


def set_epoch_learning_rate(optimizer, epoch: int, cfg: dict):
    base_lr = float(cfg["lr"])
    min_lr = float(cfg["min_lr"])
    warmup = max(0, int(cfg["warmup_epochs"]))
    decay_epochs = max(warmup + 1, int(cfg["lr_decay_epochs"]))
    if warmup > 0 and epoch <= warmup:
        lr = base_lr * float(epoch) / float(warmup)
    else:
        t = (epoch - warmup) / float(decay_epochs - warmup)
        t = min(max(t, 0.0), 1.0)
        lr = min_lr + 0.5 * (base_lr - min_lr) * (1.0 + math.cos(math.pi * t))
    for group in optimizer.param_groups:
        group["lr"] = lr
    return lr


